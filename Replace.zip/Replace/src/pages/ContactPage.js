import React from 'react'

function ContactPage() {
  return (
    <div className="contact-page">
        <div className="contact-banner">
            <div className="banner-top background">
                <div className="container">
                    <div className="banner-text">
                        <h5>CONTACT US</h5>
                        <h1>CONTACT US & REACH OUT TO YOUR NEXT ADVENTURE</h1>
                    </div>
                </div>
            </div>
            <div className="banner-img">
                <img src="./Contact-banner.png" alt="Luxury wheels for your next destination."/>
            </div>
        </div>
        <div className="contact-form">
            <div className="contact-text">
                <h5>CONTACT FORM</h5>
                <h2>GET IN TOUCH WITH US</h2>
            </div>
            <div className="form">
                <div className="form-fields row">
                    <div className="field col-lg-6 col-sm-12">
                        <input aria-required="true" aria-invalid="false" placeholder="First Name" type="text"/>
                    </div>
                    <div className="field col-lg-6 col-sm-12">
                        <input aria-required="true" aria-invalid="false" placeholder="Last Name" type="text"/>
                    </div>
                    <div className="field col-lg-6 col-sm-12">
                        <input aria-required="true" aria-invalid="false" placeholder="Mobile Number" type="text"/>
                    </div>
                    <div className="field col-lg-6 col-sm-12">
                        <input aria-required="true" aria-invalid="false" placeholder="Email" type="email"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default ContactPage