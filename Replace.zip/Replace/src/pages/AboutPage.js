import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInstagram, faFacebook, faWhatsapp } from '@fortawesome/free-brands-svg-icons';

function AboutPage() {
  return (
    <div className="about-page">
      <div className="about-banner">
        <div className="banner-top background">
          <div className="container">
            <div className="banner-text">
              <h5>WELCOME TO JGT</h5>
              <h1>LUXURY WHEELS FOR YOUR NEXT DESTINATION</h1>
            </div>
          </div>
        </div>
        <div className="banner-img">
          <img src="./About-banner.png" alt="Luxury wheels for your next destination."/>
        </div>
      </div>
      {/* === Counter pending === */}
      <div className="who-we-are">
        <div className="wwa-text-media background">
          <div className="wwa-media">
            <img src="./Who-we-are.png" alt="Who we are" loading="lazy" />
          </div>
          <div className="wwa-content">
            <div className="wwa-text">
              <h5>WHO WE ARE</h5>
              <h2>UNLEASH YOUR TRAVEL DREAMS, WE HANDLE THE WHEELS</h2>
              <p>
                We're a team of travel enthusiasts dedicated to making your journey truly exceptional. We go beyond providing vehicles; we offer expertise, personalized attention, and a commitment to exceeding your expectations.
              </p>
              <p>
                We're not just about wheels. We're about unlocking incredible journeys. Explore in comfort, freedom, and style with our diverse fleet and local expertise. Let us help you create memories that last a lifetime.
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* === Testimonial pending === */}
      <div className="what-we-do">
        <div className="wwd-text-media background">
          <div className="wwd-media">
            <img src="./What-we-do.png" alt="What we do" loading="lazy" />
          </div>
          <div className="wwd-content">
            <div className="wwd-text">
              <h5>WHAT WE DO</h5>
              <h2>DISCOVER UNFORGETTABLE JOURNEYS WITH JAY GOGA TRAVELS</h2>
              <p>
                At Jay Goga Travels, we're passionate about creating seamless and enriching travel experiences for you. Whether you dream of exploring bustling cities, venturing into untouched landscapes, or discovering hidden gems, we offer a diverse range of car rental options to fuel your travel aspirations.
              </p>
              <ul className="wwd-list">
                <li>We boast years of experience in the travel industry, ensuring a smooth and well-coordinated journey.</li>
                <li>We take the time to understand your needs and preferences, crafting a tailor-made travel experience.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div className="team">
        <div className="container">
          <div className="team-heading row">
            <h5>OUR TEAM</h5>
            <h2>MEET OUR EXPERTS</h2>
          </div>
          <div className="card col-md-4 mb-4">
            <div className="member">
              <div className="member-img">
                <img src="./Person-1.png" alt="Name" loading="lazy"/>
              </div>
              <div className="member-details">
                <FontAwesomeIcon icon={faInstagram} />
                <FontAwesomeIcon icon={faFacebook} />
                <FontAwesomeIcon icon={faWhatsapp} />
                <h4>Alex Hales</h4>
              </div>
            </div>
          </div>
          <div className="card col-md-4 mb-4">
            <div className="member">
              <div className="member-img">
                <img src="./Person-2.png" alt="Name" loading="lazy"/>
              </div>
              <div className="member-details">
                <FontAwesomeIcon icon={faInstagram} />
                <FontAwesomeIcon icon={faFacebook} />
                <FontAwesomeIcon icon={faWhatsapp} />
                <h4>Ellyse Hales</h4>
              </div>
            </div>
          </div>
          <div className="card col-md-4 mb-4">
            <div className="member">
              <div className="member-img">
                <img src="./Person-3.png" alt="Name" loading="lazy"/>
              </div>
              <div className="member-details">
                <FontAwesomeIcon icon={faInstagram} />
                <FontAwesomeIcon icon={faFacebook} />
                <FontAwesomeIcon icon={faWhatsapp} />
                <h4>Steve Hales</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AboutPage;
