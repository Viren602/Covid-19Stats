import React from "react";
import Header from "../Components/Header";

function HomePage() {
  return (
    <div>
      <Header />
      Home Page
      {/* <img src="./Home-banner.png" alt="Page" /> */}
    </div>
  );
}

export default HomePage;
