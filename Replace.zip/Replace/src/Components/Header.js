import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope, faPhone } from "@fortawesome/free-solid-svg-icons";

function Header() {
  return (
    <div className="mw-100 background">
      <div className="header-main h-10 ">
        <div className="logo-section">Logo</div>
        <div className="contact-section">
          <div className="email">
            <span className="icons">
              <FontAwesomeIcon icon={faEnvelope} />
            </span>
            <span>devtest@gmail.com</span>
          </div>
          <div className="contact">
            <span className="icons">
              <FontAwesomeIcon icon={faPhone} />
            </span>
            <span>+91 6565329874</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
